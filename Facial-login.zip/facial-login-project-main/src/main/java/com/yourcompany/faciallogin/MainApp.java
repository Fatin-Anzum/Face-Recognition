//package com.yourcompany.faciallogin;
//
//import java.io.IOException;
//import java.net.URL;
//import javafx.application.Application;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Parent;
//import javafx.scene.Scene;
//import javafx.stage.Stage;
//
//public class MainApp extends Application {
//
//    @Override
//    public void start(Stage stage) throws IOException {
//        URL fxmlLocation = getClass().getResource("login.fxml");
//        FXMLLoader fxmlLoader = new FXMLLoader(fxmlLocation);
//
//        Parent root = fxmlLoader.load();
//        Scene scene = new Scene(root, 800, 650);
//        stage.setTitle("Facial Login");
//        stage.setScene(scene);
//
//        LoginController controller = fxmlLoader.getController();
//        stage.setOnCloseRequest(event -> controller.stopCamera());
//
//        stage.show();
//    }
//
//    public static void main(String[] args) {
//        launch();
//    }
//}


//package com.yourcompany.faciallogin;
//
//public class MainApp {
//
//    public static void main(String[] args) {
//        try {
//            LoginController controller = new LoginController();
//            controller.initialize(); // Start camera & load model
//
//            // Example: Run login directly (you can change to enroll)
//            controller.handleLoginButton();
//
//            // Keep running until manually stopped
//            Runtime.getRuntime().addShutdownHook(new Thread(controller::stopCamera));
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}

//package com.yourcompany.faciallogin;
//
//import org.bytedeco.javacv.*;
//import org.bytedeco.opencv.opencv_core.Mat;
//import static org.bytedeco.opencv.global.opencv_highgui.*;
//
//public class MainApp {
//
//    public static void main(String[] args) {
//        try {
//            OpenCVFrameGrabber grabber = new OpenCVFrameGrabber(0);
//            grabber.start();
//
//            OpenCVFrameConverter.ToMat converter = new OpenCVFrameConverter.ToMat();
//
//            while (true) {
//                Frame frame = grabber.grab();
//                if (frame == null) break;
//
//                Mat mat = converter.convert(frame);
//
//                // Show webcam feed in a window
//                imshow("Webcam", mat);
//
//                // Exit when ESC key is pressed
//                if (waitKey(20) == 27) break;
//            }
//
//            grabber.stop();
//            destroyAllWindows();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}


//package com.yourcompany.faciallogin;
//
//import org.bytedeco.javacv.*;
//import org.bytedeco.opencv.opencv_core.*;
//import org.bytedeco.opencv.opencv_face.LBPHFaceRecognizer;
//import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;
//
//import static org.bytedeco.opencv.global.opencv_highgui.*;
//import static org.bytedeco.opencv.global.opencv_imgproc.*;
//
//public class MainApp {
//
//    public static void main(String[] args) {
//        String cascadePath = "E:/CSE215/Project/facial-login-project-main/haarcascade_frontalface_default.xml";
//        String modelPath = "E:/CSE215/Project/facial-login-project-main/trained_faces.xml";
//
//        CascadeClassifier faceDetector = new CascadeClassifier(cascadePath);
//        if (faceDetector.empty()) {
//            System.err.println("Error loading Haar Cascade file.");
//            return;
//        }
//
//        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
//        recognizer.read(modelPath);
//
//        try (OpenCVFrameGrabber grabber = new OpenCVFrameGrabber(0)) {
//            grabber.start();
//
//            OpenCVFrameConverter.ToMat converter = new OpenCVFrameConverter.ToMat();
//
//            while (true) {
//                Frame frame = grabber.grab();
//                if (frame == null) break;
//
//                Mat mat = converter.convert(frame);
//                Mat gray = new Mat();
//                cvtColor(mat, gray, COLOR_BGR2GRAY);
//
//                RectVector faces = new RectVector();
//                faceDetector.detectMultiScale(gray, faces);
//
//                for (int i = 0; i < faces.size(); i++) {
//                    Rect face = faces.get(i);
//
//                    Mat faceROI = new Mat(gray, face);
//                    resize(faceROI, faceROI, new Size(200, 200));
//
//                    int[] label = new int[1];
//                    double[] confidence = new double[1];
//                    recognizer.predict(faceROI, label, confidence);
//
//                    String text;
//                    if (label[0] != -1 && confidence[0] < 98 ) {
//                        text = "Recognized";
//                    } else {
//                        text = "Not Recognized";
//                    }
//                    System.out.println("Predicted label: " + label[0]);
//                    System.out.println("Confidence: " + confidence[0]);
//                    // Draw rectangle & text
//                    rectangle(mat, face, new Scalar(0, 255, 0, 0), 2, LINE_8, 0);
//                    putText(mat, text, new Point(face.x(), face.y() - 10),
//                            FONT_HERSHEY_SIMPLEX, 0.8, new Scalar(0, 255, 0, 0), 2, LINE_AA, false);
//                }
//
//                imshow("Face Recognition", mat);
//
//                if (waitKey(20) == 27) break; // ESC to exit
//            }
//
//            grabber.stop();
//            destroyAllWindows();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}

//package com.yourcompany.faciallogin;
//
//import org.bytedeco.javacv.*;
//import org.bytedeco.opencv.opencv_core.*;
//import org.bytedeco.opencv.opencv_face.LBPHFaceRecognizer;
//import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;
//
//import java.io.*;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Scanner;
//
//import static org.bytedeco.opencv.global.opencv_highgui.*;
//import static org.bytedeco.opencv.global.opencv_imgproc.*;
//
//public class MainApp {
//
//    public static void main(String[] args) {
//        String cascadePath = "E:/CSE215/Project/facial-login-project-main/haarcascade_frontalface_default.xml";
//        String modelPath = "E:/CSE215/Project/facial-login-project-main/trained_faces.xml";
//        String usersFile = "E:/CSE215/Project/facial-login-project-main/users.txt";
//
//        // Load Haar Cascade
//        CascadeClassifier faceDetector = new CascadeClassifier(cascadePath);
//        if (faceDetector.empty()) {
//            System.err.println("Error loading Haar Cascade file.");
//            return;
//        }
//
//        // Load trained model
//        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
//        recognizer.read(modelPath);
//
//        // Load user mapping (ID -> Name)
//        Map<Integer, String> userMap = new HashMap<>();
//        try (BufferedReader br = new BufferedReader(new FileReader(usersFile))) {
//            String line;
//            while ((line = br.readLine()) != null) {
//                String[] parts = line.split(",");
//                if (parts.length == 2) {
//                    String name = parts[0].trim();
//                    int id = Integer.parseInt(parts[1].trim());
//                    userMap.put(id, name);
//                }
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        // Ask for Name & ID
//        Scanner sc = new Scanner(System.in);
//        System.out.print("Enter Name: ");
//        String enteredName = sc.nextLine().trim();
//        System.out.print("Enter ID: ");
//        int enteredId = sc.nextInt();
//
//        boolean authenticated = false;
//
//        try (OpenCVFrameGrabber grabber = new OpenCVFrameGrabber(0)) {
//            grabber.start();
//            OpenCVFrameConverter.ToMat converter = new OpenCVFrameConverter.ToMat();
//
//            while (true) {
//                Frame frame = grabber.grab();
//                if (frame == null) break;
//
//                Mat mat = converter.convert(frame);
//                Mat gray = new Mat();
//                cvtColor(mat, gray, COLOR_BGR2GRAY);
//
//                RectVector faces = new RectVector();
//                faceDetector.detectMultiScale(gray, faces);
//
//                for (int i = 0; i < faces.size(); i++) {
//                    Rect face = faces.get(i);
//
//                    Mat faceROI = new Mat(gray, face);
//                    resize(faceROI, faceROI, new Size(200, 200));
//
//                    int[] label = new int[1];
//                    double[] confidence = new double[1];
//                    recognizer.predict(faceROI, label, confidence);
//
//                    String text;
//                    if (confidence[0] < 98 && label[0] == enteredId) {
//                        String predictedName = userMap.get(label[0]);
//                        if (predictedName != null && predictedName.equalsIgnoreCase(enteredName)) {
//                            text = "Welcome " + predictedName;
//                            authenticated = true;
//                        } else {
//                            text = "Access Denied";
//                        }
//                    } else {
//                        text = "Access Denied";
//                    }
//                    System.out.println("Predicted label: " + label[0]);
//                    System.out.println("Confidence: " + confidence[0]);
//                    // Draw on webcam feed
//                    rectangle(mat, face, new Scalar(0, 255, 0, 0), 2, LINE_8, 0);
//                    putText(mat, text, new Point(face.x(), face.y() - 10),
//                            FONT_HERSHEY_SIMPLEX, 0.8,
//                            authenticated ? new Scalar(0, 255, 0, 0) : new Scalar(0, 0, 255, 0),
//                            2, LINE_AA, false);
//
//                    if (authenticated) {
//                        System.out.println("✅ Access Granted! Welcome " + enteredName);
//                        imshow("Face Recognition", mat);
//                        waitKey(3000); // show for 3 seconds
//                        grabber.stop();
//                        destroyAllWindows();
//                        return;
//                    }
//                }
//
//                imshow("Face Recognition", mat);
//                if (waitKey(20) == 27) break; // ESC to exit
//            }
//
//            grabber.stop();
//            destroyAllWindows();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        if (!authenticated) {
//            System.out.println("❌ Access Denied! Face not recognized or details incorrect.");
//        }
//    }
//}

//package com.yourcompany.faciallogin;
//
//import org.bytedeco.javacv.*;
//import org.bytedeco.opencv.opencv_core.*;
//import org.bytedeco.opencv.opencv_face.LBPHFaceRecognizer;
//import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;
//
//import java.io.*;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Scanner;
//
//import static org.bytedeco.opencv.global.opencv_highgui.*;
//import static org.bytedeco.opencv.global.opencv_imgproc.*;
//
//public class MainApp {
//
//    public static void main(String[] args) {
//        String cascadePath = "E:/CSE215/Project/facial-login-project-main/haarcascade_frontalface_default.xml";
//        String modelPath = "E:/CSE215/Project/facial-login-project-main/trained_faces.xml";
//        String usersFile = "E:/CSE215/Project/facial-login-project-main/users.txt";
//
//        // Load Haar Cascade
//        CascadeClassifier faceDetector = new CascadeClassifier(cascadePath);
//        if (faceDetector.empty()) {
//            System.err.println("Error loading Haar Cascade file.");
//            return;
//        }
//
//        // Load trained model
//        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
//        recognizer.read(modelPath);
//
//        // Map: internal label -> real user name & ID
//        Map<Integer, String> labelToName = new HashMap<>();
//        Map<Integer, Integer> labelToRealId = new HashMap<>();
//
//        try (BufferedReader br = new BufferedReader(new FileReader(usersFile))) {
//            String line;
//            while ((line = br.readLine()) != null) {
//                // Format: name,realId,label
//                String[] parts = line.split(",");
//                if (parts.length == 3) {
//                    String name = parts[0].trim();
//                    int realId = Integer.parseInt(parts[1].trim());
//                    int labelId = Integer.parseInt(parts[2].trim());
//                    labelToName.put(labelId, name);
//                    labelToRealId.put(labelId, realId);
//                }
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        // Ask for Name & Real ID
//        Scanner sc = new Scanner(System.in);
//        System.out.print("Enter Name: ");
//        String enteredName = sc.nextLine().trim();
//        System.out.print("Enter ID: ");
//        int enteredRealId = sc.nextInt();
//
//        boolean authenticated = false;
//
//        try (OpenCVFrameGrabber grabber = new OpenCVFrameGrabber(0)) {
//            grabber.start();
//            OpenCVFrameConverter.ToMat converter = new OpenCVFrameConverter.ToMat();
//
//            while (true) {
//                Frame frame = grabber.grab();
//                if (frame == null) break;
//
//                Mat mat = converter.convert(frame);
//                Mat gray = new Mat();
//                cvtColor(mat, gray, COLOR_BGR2GRAY);
//
//                RectVector faces = new RectVector();
//                faceDetector.detectMultiScale(gray, faces);
//
//                for (int i = 0; i < faces.size(); i++) {
//                    Rect face = faces.get(i);
//                    Mat faceROI = new Mat(gray, face);
//                    resize(faceROI, faceROI, new Size(200, 200));
//
//                    int[] label = new int[1];
//                    double[] confidence = new double[1];
//                    recognizer.predict(faceROI, label, confidence);
//
//                    String text;
//                    if (label[0] != -1 && confidence[0] < 120) {
//                        String predictedName = labelToName.get(label[0]);
//                        Integer predictedRealId = labelToRealId.get(label[0]);
//
//                        if (predictedName != null && predictedRealId != null &&
//                                predictedName.equalsIgnoreCase(enteredName) &&
//                                predictedRealId == enteredRealId) {
//                            text = "Welcome " + predictedName;
//                            authenticated = true;
//                        } else {
//                            text = "Access Denied";
//                        }
//                    } else {
//                        text = "Access Denied";
//                    }
//
//                    System.out.println("Predicted label: " + label[0]);
//                    System.out.println("Confidence: " + confidence[0]);
//
//                    // Draw on webcam feed
//                    rectangle(mat, face, new Scalar(0, 255, 0, 0), 2, LINE_8, 0);
//                    putText(mat, text, new Point(face.x(), face.y() - 10),
//                            FONT_HERSHEY_SIMPLEX, 0.8,
//                            authenticated ? new Scalar(0, 255, 0, 0) : new Scalar(0, 0, 255, 0),
//                            2, LINE_AA, false);
//
//                    if (authenticated) {
//                        System.out.println("✅ Access Granted! Welcome " + enteredName);
//                        imshow("Face Recognition", mat);
//                        waitKey(3000); // pause for 3 seconds
//                        grabber.stop();
//                        destroyAllWindows();
//                        return;
//                    }
//                }
//
//                imshow("Face Recognition", mat);
//                if (waitKey(20) == 27) break; // ESC to exit
//            }
//
//            grabber.stop();
//            destroyAllWindows();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        if (!authenticated) {
//            System.out.println("❌ Access Denied! Face not recognized or details incorrect.");
//        }
//    }
//}
package com.yourcompany.faciallogin;

import org.bytedeco.javacv.*;
import org.bytedeco.opencv.opencv_core.*;
import org.bytedeco.opencv.opencv_face.LBPHFaceRecognizer;
import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import static org.bytedeco.opencv.global.opencv_highgui.*;
import static org.bytedeco.opencv.global.opencv_imgproc.*;

public class MainApp {

    public static void main(String[] args) {
        String cascadePath = "E:/CSE215/Project/facial-login-project-main/haarcascade_frontalface_default.xml";
        String modelPath = "E:/CSE215/Project/facial-login-project-main/trained_faces.xml";
        String usersFile = "E:/CSE215/Project/facial-login-project-main/users.txt";

        // Load Haar Cascade
        CascadeClassifier faceDetector = new CascadeClassifier(cascadePath);
        if (faceDetector.empty()) {
            System.err.println("❌ Error loading Haar Cascade file.");
            return;
        }

        // Load trained model
        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
        recognizer.read(modelPath);

        // Load user mapping (ID -> Name)
        Map<Integer, String> userMap = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(usersFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String name = parts[0].trim();
                    int id = Integer.parseInt(parts[1].trim());
                    userMap.put(id, name);
                }
            }
        } catch (IOException e) {
            System.err.println("❌ Failed to load users.txt");
            e.printStackTrace();
            return;
        }

        // Ask for Name & ID
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Name: ");
        String enteredName = sc.nextLine().trim();
        System.out.print("Enter ID: ");
        int enteredId = sc.nextInt();

        boolean authenticated = false;

        try (OpenCVFrameGrabber grabber = new OpenCVFrameGrabber(0)) {
            grabber.start();
            OpenCVFrameConverter.ToMat converter = new OpenCVFrameConverter.ToMat();

            while (true) {
                Frame frame = grabber.grab();
                if (frame == null) break;

                Mat mat = converter.convert(frame);
                Mat gray = new Mat();
                cvtColor(mat, gray, COLOR_BGR2GRAY);

                RectVector faces = new RectVector();
                faceDetector.detectMultiScale(gray, faces);

                for (int i = 0; i < faces.size(); i++) {
                    Rect face = faces.get(i);

                    Mat faceROI = new Mat(gray, face);
                    resize(faceROI, faceROI, new Size(200, 200));

                    int[] label = new int[1];
                    double[] confidence = new double[1];
                    recognizer.predict(faceROI, label, confidence);

                    String text;
                    if (confidence[0] < 80 && label[0] == enteredId) { // 80 is more strict
                        String predictedName = userMap.get(label[0]);
                        if (predictedName != null && predictedName.equalsIgnoreCase(enteredName)) {
                            text = "Welcome " + predictedName;
                            authenticated = true;
                        } else {
                            text = "Access Denied";
                        }
                    } else {
                        text = "Access Denied";
                    }

                    System.out.println("Predicted label: " + label[0]);
                    System.out.println("Confidence: " + confidence[0]);

                    rectangle(mat, face, new Scalar(0, 255, 0, 0), 2, LINE_8, 0);
                    putText(mat, text, new Point(face.x(), face.y() - 10),
                            FONT_HERSHEY_SIMPLEX, 0.8,
                            authenticated ? new Scalar(0, 255, 0, 0) : new Scalar(0, 0, 255, 0),
                            2, LINE_AA, false);

                    if (authenticated) {
                        System.out.println("✅ Access Granted! Welcome " + enteredName);
                        imshow("Face Recognition", mat);
                        waitKey(3000);
                        grabber.stop();
                        destroyAllWindows();
                        return;
                    }
                }

                imshow("Face Recognition", mat);
                if (waitKey(20) == 27) break; // ESC to exit
            }

            grabber.stop();
            destroyAllWindows();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (!authenticated) {
            System.out.println("❌ Access Denied! Face not recognized or details incorrect.");
        }
    }
}



