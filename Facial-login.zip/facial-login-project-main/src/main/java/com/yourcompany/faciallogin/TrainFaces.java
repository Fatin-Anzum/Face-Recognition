//package com.yourcompany.faciallogin;
//
//import org.bytedeco.javacpp.*;
//import org.bytedeco.opencv.opencv_core.*;
//import org.bytedeco.opencv.opencv_face.*;
//import static org.bytedeco.opencv.global.opencv_core.*;
//import static org.bytedeco.opencv.global.opencv_imgcodecs.*;
//import org.bytedeco.opencv.opencv_imgproc.*;
//import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;
//
//import java.io.File;
//import java.nio.IntBuffer;
//import java.util.ArrayList;
//import java.util.List;
//
//import static org.bytedeco.opencv.global.opencv_core.CV_8UC1;
//import static org.bytedeco.opencv.global.opencv_imgcodecs.imread;
//import static org.bytedeco.opencv.global.opencv_imgproc.resize;
//
//public class TrainFaces {
//
//    public static void main(String[] args) {
//        // Paths
//        String datasetPath = "E:/CSE215/Project/facial-login-project-main/dataset";
//        String cascadePath = "E:/CSE215/Project/facial-login-project-main/haarcascade_frontalface_default.xml";
//        String outputFile = "E:/CSE215/Project/facial-login-project-main/trained_faces.xml";
//
//        // Haar Cascade for face detection
//        CascadeClassifier faceDetector = new CascadeClassifier(cascadePath);
//        if (faceDetector.empty()) {
//            System.err.println("Error loading Haar Cascade file.");
//            return;
//        }
//
//        List<Mat> images = new ArrayList<>();
//        List<Integer> labels = new ArrayList<>();
//
//        File[] personDirs = new File(datasetPath).listFiles(File::isDirectory);
//        if (personDirs == null) {
//            System.err.println("No person folders found in dataset path.");
//            return;
//        }
//
//        int labelCounter = 0;
//        for (File personDir : personDirs) {
//            labelCounter++;
//            File[] files = personDir.listFiles((dir, name) ->
//                    name.toLowerCase().endsWith(".jpg") ||
//                            name.toLowerCase().endsWith(".png"));
//
//            if (files == null) continue;
//
//            for (File imgFile : files) {
//                Mat imgColor = imread(imgFile.getAbsolutePath());
//                if (imgColor.empty()) {
//                    System.err.println("Could not read image: " + imgFile);
//                    continue;
//                }
//
//                Mat imgGray = new Mat();
//                org.bytedeco.opencv.global.opencv_imgproc.cvtColor(imgColor, imgGray, org.bytedeco.opencv.global.opencv_imgproc.COLOR_BGR2GRAY);
//
//                RectVector faces = new RectVector();
//                faceDetector.detectMultiScale(imgGray, faces);
//
//                if (faces.size() == 0) {
//                    System.out.println("No face detected in " + imgFile.getName());
//                    continue;
//                }
//
//                Rect face = faces.get(0);
//                Mat faceROI = new Mat(imgGray, face);
//
//                resize(faceROI, faceROI, new Size(200, 200));
//
//                images.add(faceROI);
//                labels.add(labelCounter);
//            }
//        }
//
//        if (images.isEmpty()) {
//            System.err.println("No faces found for training.");
//            return;
//        }
//
//        // Prepare labels Mat
//        Mat labelsMat = new Mat(labels.size(), 1, CV_32SC1);
//        IntBuffer labelsBuf = labelsMat.createBuffer();
//        for (int label : labels) {
//            labelsBuf.put(label);
//        }
//
//        // Train recognizer
//        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
//        recognizer.train((MatVector) images, labelsMat);
//
//        recognizer.save(outputFile);
//        System.out.println("Training complete. Model saved to: " + outputFile);
//    }
//}


//package com.yourcompany.faciallogin;
//
//import org.bytedeco.javacpp.*;
//import org.bytedeco.opencv.opencv_core.*;
//import org.bytedeco.opencv.opencv_face.*;
//import static org.bytedeco.opencv.global.opencv_core.*;
//import static org.bytedeco.opencv.global.opencv_imgcodecs.*;
//import org.bytedeco.opencv.opencv_imgproc.*;
//import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;
//
//import java.io.File;
//import java.nio.IntBuffer;
//import java.util.ArrayList;
//import java.util.List;
//
//import static org.bytedeco.opencv.global.opencv_imgcodecs.imread;
//import static org.bytedeco.opencv.global.opencv_imgproc.resize;
//
//public class TrainFaces {
//
//    public static void main(String[] args) {
//        // Paths
//        String datasetPath = "E:/CSE215/Project/facial-login-project-main/dataset";
//        String cascadePath = "E:/CSE215/Project/facial-login-project-main/haarcascade_frontalface_default.xml";
//        String outputFile = "E:/CSE215/Project/facial-login-project-main/trained_faces.xml";
//
//        // Haar Cascade for face detection
//        CascadeClassifier faceDetector = new CascadeClassifier(cascadePath);
//        if (faceDetector.empty()) {
//            System.err.println("Error loading Haar Cascade file.");
//            return;
//        }
//
//        List<Mat> images = new ArrayList<>();
//        List<Integer> labels = new ArrayList<>();
//
//        File[] personDirs = new File(datasetPath).listFiles(File::isDirectory);
//        if (personDirs == null) {
//            System.err.println("No person folders found in dataset path.");
//            return;
//        }
//
//        int labelCounter = 0;
//        for (File personDir : personDirs) {
//            labelCounter++;
//            File[] files = personDir.listFiles((dir, name) ->
//                    name.toLowerCase().endsWith(".jpg") ||
//                            name.toLowerCase().endsWith(".png") || name.toLowerCase().endsWith(".jpeg"));
//
//            if (files == null) continue;
//
//            for (File imgFile : files) {
//                Mat imgColor = imread(imgFile.getAbsolutePath());
//                if (imgColor.empty()) {
//                    System.err.println("Could not read image: " + imgFile);
//                    continue;
//                }
//
//                Mat imgGray = new Mat();
//                org.bytedeco.opencv.global.opencv_imgproc.cvtColor(
//                        imgColor, imgGray,
//                        org.bytedeco.opencv.global.opencv_imgproc.COLOR_BGR2GRAY
//                );
//
//                RectVector faces = new RectVector();
//                faceDetector.detectMultiScale(imgGray, faces);
//
//                if (faces.size() == 0) {
//                    System.out.println("No face detected in " + imgFile.getName());
//                    continue;
//                }
//
//                Rect face = faces.get(0);
//                Mat faceROI = new Mat(imgGray, face);
//
//                resize(faceROI, faceROI, new Size(200, 200));
//
//                images.add(faceROI);
//                labels.add(labelCounter);
//            }
//        }
//
//        if (images.isEmpty()) {
//            System.err.println("No faces found for training.");
//            return;
//        }
//
//        // Convert List<Mat> to MatVector
//        MatVector imagesMatVector = new MatVector(images.size());
//        for (int i = 0; i < images.size(); i++) {
//            imagesMatVector.put(i, images.get(i));
//        }
//
//        // Prepare labels Mat
//        Mat labelsMat = new Mat(labels.size(), 1, CV_32SC1);
//        IntBuffer labelsBuf = labelsMat.createBuffer();
//        for (int label : labels) {
//            labelsBuf.put(label);
//        }
//
//        // Train recognizer
//        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
//        recognizer.train(imagesMatVector, labelsMat);
//
//        // Save trained model
//        recognizer.save(outputFile);
//        System.out.println("Training complete. Model saved to: " + outputFile);
//    }
//}

//package com.yourcompany.faciallogin;
//
//import org.bytedeco.opencv.opencv_core.*;
////import org.bytedeco.opencv.opencv_imgcodecs.*;
////import org.bytedeco.opencv.opencv_imgproc.*;
//import static org.bytedeco.opencv.global.opencv_imgcodecs.*;
//import static org.bytedeco.opencv.global.opencv_imgproc.*;
//import org.bytedeco.opencv.opencv_core.*;
//import org.bytedeco.opencv.opencv_face.LBPHFaceRecognizer;
//
//import org.bytedeco.opencv.opencv_face.LBPHFaceRecognizer;
//import org.opencv.core.CvType;
//
//import java.io.*;
//import java.nio.file.*;
//import java.util.*;
//
//import static org.bytedeco.opencv.global.opencv_imgcodecs.*;
//import static org.bytedeco.opencv.global.opencv_imgproc.*;
//
//public class TrainFaces {
//
//    public static void main(String[] args) throws IOException {
//        String datasetPath = "E:/CSE215/Project/facial-login-project-main/dataset";
//        String modelPath = "E:/CSE215/Project/facial-login-project-main/trained_faces.xml";
//        String usersFile = "E:/CSE215/Project/facial-login-project-main/users.txt";
//
//        List<Mat> images = new ArrayList<>();
//        List<Integer> labels = new ArrayList<>();
//        int labelCounter = 1; // Start from 1 (OpenCV standard)
//
//        // Prepare to write users.txt
//        try (BufferedWriter bw = new BufferedWriter(new FileWriter(usersFile))) {
//
//            // Loop through dataset folders
//            File datasetDir = new File(datasetPath);
//            File[] personDirs = datasetDir.listFiles(File::isDirectory);
//
//            if (personDirs == null) {
//                System.err.println("No dataset found at: " + datasetPath);
//                return;
//            }
//
//            for (File personDir : personDirs) {
//                // Folder format: name_realId
//                String folderName = personDir.getName();
//                String[] parts = folderName.split("_");
//
//                if (parts.length != 2) {
//                    System.err.println("Skipping invalid folder: " + folderName);
//                    continue;
//                }
//
//                String name = parts[0];
//                int realId;
//                try {
//                    realId = Integer.parseInt(parts[1]);
//                } catch (NumberFormatException e) {
//                    System.err.println("Invalid ID in folder name: " + folderName);
//                    continue;
//                }
//
//                System.out.println("Processing: " + name + " (" + realId + ")");
//
//                // Write mapping to users.txt
//                bw.write(name + "," + realId + "," + labelCounter);
//                bw.newLine();
//
//                // Load images from this folder
//                File[] imgFiles = personDir.listFiles((dir, nameFile) ->
//                        nameFile.toLowerCase().endsWith(".jpg") ||
//                                nameFile.toLowerCase().endsWith(".png"));
//
//                if (imgFiles == null) continue;
//
//                for (File imgFile : imgFiles) {
//                    Mat img = imread(imgFile.getAbsolutePath(), IMREAD_GRAYSCALE);
//                    if (img.empty()) {
//                        System.err.println("Could not read: " + imgFile.getName());
//                        continue;
//                    }
//
//                    resize(img, img, new Size(200, 200));
//                    images.add(img);
//                    labels.add(labelCounter);
//                }
//
//                labelCounter++;
//            }
//        }
//
//        // Convert to MatOfInt and MatOfByte for training
//        Mat labelsMat = new Mat(labels.size(), 1, CvType.CV_32SC1);
//        for (int i = 0; i < labels.size(); i++) {
//            labelsMat.ptr(i).putInt(labels.get(i));
//        }
//
//        // Train LBPH Face Recognizer
//        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
//        recognizer.train((MatVector) images, labelsMat);
//        recognizer.save(modelPath);
//
//        System.out.println("✅ Training completed!");
//        System.out.println("Model saved to: " + modelPath);
//        System.out.println("Users mapping saved to: " + usersFile);
//    }
//}
package com.yourcompany.faciallogin;

import org.bytedeco.opencv.opencv_core.*;
import org.bytedeco.opencv.opencv_face.LBPHFaceRecognizer;
import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.IntBuffer;
import java.util.ArrayList;

import static org.bytedeco.opencv.global.opencv_core.*;
import static org.bytedeco.opencv.global.opencv_imgcodecs.*;
import static org.bytedeco.opencv.global.opencv_imgproc.*;

public class TrainFaces {

    public static void main(String[] args) {
        String datasetPath = "E:/CSE215/Project/facial-login-project-main/dataset";
        String cascadePath = "E:/CSE215/Project/facial-login-project-main/haarcascade_frontalface_default.xml";
        String modelPath = "E:/CSE215/Project/facial-login-project-main/trained_faces.xml";
        String usersFile = "E:/CSE215/Project/facial-login-project-main/users.txt";

        CascadeClassifier faceDetector = new CascadeClassifier(cascadePath);
        if (faceDetector.empty()) {
            System.err.println("❌ Error loading Haar Cascade file.");
            return;
        }

        ArrayList<Mat> faceImages = new ArrayList<>();
        ArrayList<Integer> faceLabels = new ArrayList<>();
        StringBuilder userFileContent = new StringBuilder();

        File root = new File(datasetPath);
        File[] personDirs = root.listFiles();
        if (personDirs == null) {
            System.err.println("❌ Dataset folder not found or empty.");
            return;
        }

        for (File personDir : personDirs) {
            if (!personDir.isDirectory()) continue;

            // Folder name format: name_id
            String[] nameId = personDir.getName().split("_");
            if (nameId.length != 2) {
                System.err.println("⚠ Skipping folder: " + personDir.getName() + " (invalid name_id format)");
                continue;
            }
            String name = nameId[0];
            int id;
            try {
                id = Integer.parseInt(nameId[1]);
            } catch (NumberFormatException e) {
                System.err.println("⚠ Invalid ID for: " + personDir.getName());
                continue;
            }

            // Store mapping in users.txt format: name,id
            userFileContent.append(name).append(",").append(id).append("\n");

            // Load all images in this folder
            File[] images = personDir.listFiles();
            if (images == null) continue;

            for (File imageFile : images) {
                Mat img = imread(imageFile.getAbsolutePath());
                if (img.empty()) {
                    System.err.println("⚠ Could not read image: " + imageFile.getName());
                    continue;
                }

                Mat gray = new Mat();
                cvtColor(img, gray, COLOR_BGR2GRAY);

                RectVector faces = new RectVector();
                faceDetector.detectMultiScale(gray, faces);

                for (int i = 0; i < faces.size(); i++) {
                    Rect face = faces.get(i);
                    Mat faceROI = new Mat(gray, face);
                    resize(faceROI, faceROI, new Size(200, 200));

                    faceImages.add(faceROI);
                    faceLabels.add(id);
                }
            }
        }

        if (faceImages.isEmpty()) {
            System.err.println("❌ No faces found in dataset.");
            return;
        }

        // Convert ArrayList to MatVector
        MatVector imagesVector = new MatVector(faceImages.size());
        Mat labelsMat = new Mat(faceImages.size(), 1, CV_32SC1);
        IntBuffer labelsBuf = labelsMat.createBuffer();

        for (int i = 0; i < faceImages.size(); i++) {
            imagesVector.put(i, faceImages.get(i));
            labelsBuf.put(i, faceLabels.get(i));
        }

        // Train and save model
        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
        recognizer.train(imagesVector, labelsMat);
        recognizer.save(modelPath);

        System.out.println("✅ Training complete. Model saved at: " + modelPath);

        // Save users.txt mapping
        try (FileWriter fw = new FileWriter(usersFile)) {
            fw.write(userFileContent.toString());
            System.out.println("✅ Users file saved at: " + usersFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

