package com.yourcompany.faciallogin;

import java.io.*;
import java.util.*;

//abstract class Users{
//   protected int id;
//   abstract boolean userLogin(int id);
//}
//
//class admin {
//    private int adId= 2511517;
//    private String adPass = "$99pw";
//
//    admin () {
//
//    }
//}

//public class Users {
//    private String userId;
//    private String password;
//    private int label; // The label used in face recognition
//
//    public Users(String userId, String password, int label) {
//        this.userId = userId;
//        this.password = password;
//        this.label = label;
//    }
//
//    public String getUserId() { return userId; }
//    public String getPassword() { return password; }
//    public int getLabel() { return label; }
//
//    public void setUserId(String userId) { this.userId = userId; }
//    public void setPassword(String password) { this.password = password; }
//    public void setLabel(int label) { this.label = label; }
//}

public class Users {
    private String name;
    private int userId; // numeric ID
    private int label;  // label used in face recognition

    public Users(String name, int userId, int label) {
        this.name = name;
        this.userId = userId;
        this.label = label;
    }

    public String getName() { return name; }
    public int getUserId() { return userId; }
    public int getLabel() { return label; }

    public void setName(String name) { this.name = name; }
    public void setUserId(int userId) { this.userId = userId; }
    public void setLabel(int label) { this.label = label; }
}