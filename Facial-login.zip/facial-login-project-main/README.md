# Facial Recognition Login System

A proof-of-concept desktop application built with JavaFX and JavaCV that demonstrates a facial recognition login system. Users can enroll their face, train a recognition model, and log in using their camera.

## Application Workflow

The following diagram illustrates the application's workflow:

```mermaid
graph TD
    A[Start Application] --> B{Camera Initialized};
    B --> C{Face Detected?};
    C -- No --> B;
    C -- Yes --> D[Draw Rectangle Around Face];
    D --> E{User Action};
    E -- Click 'Enroll' --> F[Capture 30 Face Samples];
    F --> G[Train LBPH Model];
    G --> H[Save 'trained_model.yml'];
    H --> I[Ready to Login];
    E -- Click 'Login' --> J[Load 'trained_model.yml'];
    J --> K[Predict Face];
    K --> L{Confidence < 60?};
    L -- Yes --> M[Login Successful];
    L -- No --> N[Unknown User];
```

## Key Features

- **Live Camera Feed**: Real-time video stream using the default system camera.
- **Face Detection**: Automatically detects and highlights human faces in the video feed using Haar Cascades.
- **User Enrollment**: Capture and save face samples for a new user under a given name/ID.
- **Model Training**: Trains a Local Binary Patterns Histograms (LBPH) face recognition model on the enrolled faces.
- **Facial Login**: Recognizes enrolled users and simulates a login event.

## Technology Stack

- **Java 11**: Core programming language.
- **JavaFX 17**: Used for building the graphical user interface.
- **JavaCV (OpenCV 4.5.5)**: A Java wrapper for OpenCV used for camera access, face detection, and recognition.
- **Maven**: For project build management and dependency resolution.

## Project Structure

The project follows the standard Maven directory layout:

```
.
├── pom.xml
├── src
│   └── main
│       ├── java
│       │   └── com
│       │       └── yourcompany
│       │           └── faciallogin
│       │               ├── LoginController.java
│       │               └── MainApp.java
│       └── resources
│           ├── cascades
│           │   └── haarcascade_frontalface_alt.xml
│           ├── com
│           │   └── yourcompany
│           │       └── faciallogin
│           │           └── login.fxml
│           ├── faces
│           └── trained_model.yml
└── .gitignore
```

## Prerequisites

Before you begin, ensure you have the following installed on your system:

- **Java Development Kit (JDK) 11**: The project is configured to use Java 11.
- **Apache Maven**: To build the project and manage dependencies.

For macOS users with Homebrew, you can install them with:

```bash
# Install Zulu JDK 11 for Apple Silicon/Intel
brew install --cask zulu11

# Install Maven
brew install maven
```

## Installation & Setup

1. **Clone the repository**:

```bash
git clone https://your-repository-url/facial-login.git
cd facial-login
```

2. **Build and Run the Application**:

Use Maven to compile the source code, download dependencies, and launch the application:

```bash
mvn clean javafx:run
```

The first time you run this, Maven will download all the required libraries, which may take a few minutes. On subsequent runs, it will be much faster.

**Note for macOS Users**: The first time the application runs, macOS will prompt you for permission to access the camera. You must click OK.

## How to Use

### 1. Enroll a New User

- Enter the user's name in the "Name/ID" text field.
- Click the **Enroll New User** button.
- Look directly at the camera. The application will capture 30 images of your face. The status label will show the progress.
- Once capturing is complete, the system will automatically train the recognition model. The status will update to "Model trained. Ready to login."

### 2. Login

- After at least one user has been enrolled, click the **Login** button.
- Look directly at the camera.
- If the system recognizes your face with sufficient confidence, the status will change to "Login Successful!". Otherwise, it will label you as "Unknown".

## Visualization

Below is a visualization of the application's user interface:

![UI Mockup](ui_mockup.png)

**UI Mockup Description**:
- A live camera feed displays the video stream with a rectangle drawn around detected faces.
- A text field allows the user to input their Name/ID for enrollment.
- Two buttons: "Enroll New User" to capture face samples and "Login" to attempt facial recognition.
- A status label displays messages like "Capturing face 1/30", "Model trained", or "Login Successful!".

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.