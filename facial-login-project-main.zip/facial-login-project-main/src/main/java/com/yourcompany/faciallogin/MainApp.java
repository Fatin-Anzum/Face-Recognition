//package com.yourcompany.faciallogin;
//
//import java.io.IOException;
//import java.net.URL;
//import javafx.application.Application;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Parent;
//import javafx.scene.Scene;
//import javafx.stage.Stage;
//
//public class MainApp extends Application {
//
//    @Override
//    public void start(Stage stage) throws IOException {
//        URL fxmlLocation = getClass().getResource("login.fxml");
//        FXMLLoader fxmlLoader = new FXMLLoader(fxmlLocation);
//
//        Parent root = fxmlLoader.load();
//        Scene scene = new Scene(root, 800, 650);
//        stage.setTitle("Facial Login");
//        stage.setScene(scene);
//
//        LoginController controller = fxmlLoader.getController();
//        stage.setOnCloseRequest(event -> controller.stopCamera());
//
//        stage.show();
//    }
//
//    public static void main(String[] args) {
//        launch();
//    }
//}


//package com.yourcompany.faciallogin;
//
//public class MainApp {
//
//    public static void main(String[] args) {
//        try {
//            LoginController controller = new LoginController();
//            controller.initialize(); // Start camera & load model
//
//            // Example: Run login directly (you can change to enroll)
//            controller.handleLoginButton();
//
//            // Keep running until manually stopped
//            Runtime.getRuntime().addShutdownHook(new Thread(controller::stopCamera));
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}

//package com.yourcompany.faciallogin;
//
//import org.bytedeco.javacv.*;
//import org.bytedeco.opencv.opencv_core.Mat;
//import static org.bytedeco.opencv.global.opencv_highgui.*;
//
//public class MainApp {
//
//    public static void main(String[] args) {
//        try {
//            OpenCVFrameGrabber grabber = new OpenCVFrameGrabber(0);
//            grabber.start();
//
//            OpenCVFrameConverter.ToMat converter = new OpenCVFrameConverter.ToMat();
//
//            while (true) {
//                Frame frame = grabber.grab();
//                if (frame == null) break;
//
//                Mat mat = converter.convert(frame);
//
//                // Show webcam feed in a window
//                imshow("Webcam", mat);
//
//                // Exit when ESC key is pressed
//                if (waitKey(20) == 27) break;
//            }
//
//            grabber.stop();
//            destroyAllWindows();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}


package com.yourcompany.faciallogin;

import org.bytedeco.javacv.*;
import org.bytedeco.opencv.opencv_core.*;
import org.bytedeco.opencv.opencv_face.LBPHFaceRecognizer;
import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;

import static org.bytedeco.opencv.global.opencv_highgui.*;
import static org.bytedeco.opencv.global.opencv_imgproc.*;

public class MainApp {

    public static void main(String[] args) {
        String cascadePath = "E:/CSE215/Project/facial-login-project-main/haarcascade_frontalface_default.xml";
        String modelPath = "E:/CSE215/Project/facial-login-project-main/trained_faces.xml";

        CascadeClassifier faceDetector = new CascadeClassifier(cascadePath);
        if (faceDetector.empty()) {
            System.err.println("Error loading Haar Cascade file.");
            return;
        }

        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
        recognizer.read(modelPath);

        try (OpenCVFrameGrabber grabber = new OpenCVFrameGrabber(0)) {
            grabber.start();

            OpenCVFrameConverter.ToMat converter = new OpenCVFrameConverter.ToMat();

            while (true) {
                Frame frame = grabber.grab();
                if (frame == null) break;

                Mat mat = converter.convert(frame);
                Mat gray = new Mat();
                cvtColor(mat, gray, COLOR_BGR2GRAY);

                RectVector faces = new RectVector();
                faceDetector.detectMultiScale(gray, faces);

                for (int i = 0; i < faces.size(); i++) {
                    Rect face = faces.get(i);

                    Mat faceROI = new Mat(gray, face);
                    resize(faceROI, faceROI, new Size(200, 200));

                    int[] label = new int[1];
                    double[] confidence = new double[1];
                    recognizer.predict(faceROI, label, confidence);

                    String text;
                    if (label[0] != -1 && confidence[0] < 70) {
                        text = "Recognized";
                    } else {
                        text = "Not Recognized";
                    }

                    // Draw rectangle & text
                    rectangle(mat, face, new Scalar(0, 255, 0, 0), 2, LINE_8, 0);
                    putText(mat, text, new Point(face.x(), face.y() - 10),
                            FONT_HERSHEY_SIMPLEX, 0.8, new Scalar(0, 255, 0, 0), 2, LINE_AA, false);
                }

                imshow("Face Recognition", mat);

                if (waitKey(20) == 27) break; // ESC to exit
            }

            grabber.stop();
            destroyAllWindows();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


