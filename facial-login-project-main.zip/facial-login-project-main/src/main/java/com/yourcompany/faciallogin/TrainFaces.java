//package com.yourcompany.faciallogin;
//
//import org.bytedeco.javacpp.*;
//import org.bytedeco.opencv.opencv_core.*;
//import org.bytedeco.opencv.opencv_face.*;
//import static org.bytedeco.opencv.global.opencv_core.*;
//import static org.bytedeco.opencv.global.opencv_imgcodecs.*;
//import org.bytedeco.opencv.opencv_imgproc.*;
//import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;
//
//import java.io.File;
//import java.nio.IntBuffer;
//import java.util.ArrayList;
//import java.util.List;
//
//import static org.bytedeco.opencv.global.opencv_core.CV_8UC1;
//import static org.bytedeco.opencv.global.opencv_imgcodecs.imread;
//import static org.bytedeco.opencv.global.opencv_imgproc.resize;
//
//public class TrainFaces {
//
//    public static void main(String[] args) {
//        // Paths
//        String datasetPath = "E:/CSE215/Project/facial-login-project-main/dataset";
//        String cascadePath = "E:/CSE215/Project/facial-login-project-main/haarcascade_frontalface_default.xml";
//        String outputFile = "E:/CSE215/Project/facial-login-project-main/trained_faces.xml";
//
//        // Haar Cascade for face detection
//        CascadeClassifier faceDetector = new CascadeClassifier(cascadePath);
//        if (faceDetector.empty()) {
//            System.err.println("Error loading Haar Cascade file.");
//            return;
//        }
//
//        List<Mat> images = new ArrayList<>();
//        List<Integer> labels = new ArrayList<>();
//
//        File[] personDirs = new File(datasetPath).listFiles(File::isDirectory);
//        if (personDirs == null) {
//            System.err.println("No person folders found in dataset path.");
//            return;
//        }
//
//        int labelCounter = 0;
//        for (File personDir : personDirs) {
//            labelCounter++;
//            File[] files = personDir.listFiles((dir, name) ->
//                    name.toLowerCase().endsWith(".jpg") ||
//                            name.toLowerCase().endsWith(".png"));
//
//            if (files == null) continue;
//
//            for (File imgFile : files) {
//                Mat imgColor = imread(imgFile.getAbsolutePath());
//                if (imgColor.empty()) {
//                    System.err.println("Could not read image: " + imgFile);
//                    continue;
//                }
//
//                Mat imgGray = new Mat();
//                org.bytedeco.opencv.global.opencv_imgproc.cvtColor(imgColor, imgGray, org.bytedeco.opencv.global.opencv_imgproc.COLOR_BGR2GRAY);
//
//                RectVector faces = new RectVector();
//                faceDetector.detectMultiScale(imgGray, faces);
//
//                if (faces.size() == 0) {
//                    System.out.println("No face detected in " + imgFile.getName());
//                    continue;
//                }
//
//                Rect face = faces.get(0);
//                Mat faceROI = new Mat(imgGray, face);
//
//                resize(faceROI, faceROI, new Size(200, 200));
//
//                images.add(faceROI);
//                labels.add(labelCounter);
//            }
//        }
//
//        if (images.isEmpty()) {
//            System.err.println("No faces found for training.");
//            return;
//        }
//
//        // Prepare labels Mat
//        Mat labelsMat = new Mat(labels.size(), 1, CV_32SC1);
//        IntBuffer labelsBuf = labelsMat.createBuffer();
//        for (int label : labels) {
//            labelsBuf.put(label);
//        }
//
//        // Train recognizer
//        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
//        recognizer.train((MatVector) images, labelsMat);
//
//        recognizer.save(outputFile);
//        System.out.println("Training complete. Model saved to: " + outputFile);
//    }
//}


package com.yourcompany.faciallogin;

import org.bytedeco.javacpp.*;
import org.bytedeco.opencv.opencv_core.*;
import org.bytedeco.opencv.opencv_face.*;
import static org.bytedeco.opencv.global.opencv_core.*;
import static org.bytedeco.opencv.global.opencv_imgcodecs.*;
import org.bytedeco.opencv.opencv_imgproc.*;
import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;

import java.io.File;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;

import static org.bytedeco.opencv.global.opencv_imgcodecs.imread;
import static org.bytedeco.opencv.global.opencv_imgproc.resize;

public class TrainFaces {

    public static void main(String[] args) {
        // Paths
        String datasetPath = "E:/CSE215/Project/facial-login-project-main/dataset";
        String cascadePath = "E:/CSE215/Project/facial-login-project-main/haarcascade_frontalface_default.xml";
        String outputFile = "E:/CSE215/Project/facial-login-project-main/trained_faces.xml";

        // Haar Cascade for face detection
        CascadeClassifier faceDetector = new CascadeClassifier(cascadePath);
        if (faceDetector.empty()) {
            System.err.println("Error loading Haar Cascade file.");
            return;
        }

        List<Mat> images = new ArrayList<>();
        List<Integer> labels = new ArrayList<>();

        File[] personDirs = new File(datasetPath).listFiles(File::isDirectory);
        if (personDirs == null) {
            System.err.println("No person folders found in dataset path.");
            return;
        }

        int labelCounter = 0;
        for (File personDir : personDirs) {
            labelCounter++;
            File[] files = personDir.listFiles((dir, name) ->
                    name.toLowerCase().endsWith(".jpg") ||
                            name.toLowerCase().endsWith(".png"));

            if (files == null) continue;

            for (File imgFile : files) {
                Mat imgColor = imread(imgFile.getAbsolutePath());
                if (imgColor.empty()) {
                    System.err.println("Could not read image: " + imgFile);
                    continue;
                }

                Mat imgGray = new Mat();
                org.bytedeco.opencv.global.opencv_imgproc.cvtColor(
                        imgColor, imgGray,
                        org.bytedeco.opencv.global.opencv_imgproc.COLOR_BGR2GRAY
                );

                RectVector faces = new RectVector();
                faceDetector.detectMultiScale(imgGray, faces);

                if (faces.size() == 0) {
                    System.out.println("No face detected in " + imgFile.getName());
                    continue;
                }

                Rect face = faces.get(0);
                Mat faceROI = new Mat(imgGray, face);

                resize(faceROI, faceROI, new Size(200, 200));

                images.add(faceROI);
                labels.add(labelCounter);
            }
        }

        if (images.isEmpty()) {
            System.err.println("No faces found for training.");
            return;
        }

        // Convert List<Mat> to MatVector
        MatVector imagesMatVector = new MatVector(images.size());
        for (int i = 0; i < images.size(); i++) {
            imagesMatVector.put(i, images.get(i));
        }

        // Prepare labels Mat
        Mat labelsMat = new Mat(labels.size(), 1, CV_32SC1);
        IntBuffer labelsBuf = labelsMat.createBuffer();
        for (int label : labels) {
            labelsBuf.put(label);
        }

        // Train recognizer
        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
        recognizer.train(imagesMatVector, labelsMat);

        // Save trained model
        recognizer.save(outputFile);
        System.out.println("Training complete. Model saved to: " + outputFile);
    }
}
