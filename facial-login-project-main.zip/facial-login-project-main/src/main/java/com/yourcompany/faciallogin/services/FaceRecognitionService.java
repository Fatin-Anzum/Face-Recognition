package com.yourcompany.faciallogin.services;

public class FaceRecognitionService {}
